﻿using System.IO;
using System.Text.RegularExpressions;

namespace App_Integration.PDF.Extended
{
    public class PDFHelpers
    {
        public static int GetPageCount(string file)
        {
            using (StreamReader sr = new StreamReader(File.OpenRead(file)))
            {
                Regex regex = new Regex(@"/Type\s*/Page[^s]");
                MatchCollection matches = regex.Matches(sr.ReadToEnd());

                return matches.Count;
            }
        }
    }
}