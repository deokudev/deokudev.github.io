﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Activities;
using System.ComponentModel;
using System.IO;
using System.Text;

namespace App_Integration.PDF.Extended
{
    [DisplayName("Extract Pages")]
    public class ExtractPages : CodeActivity
    {
        [Category("File")]
        [DisplayName("FileName")]
        [RequiredArgument]
        public InArgument<string> SourceFile { get; set; }

        [Category("File")]
        [DisplayName("Password")]
        public InArgument<string> Password { get; set; }

        [Category("Input")]
        [DisplayName("Range")]
        [RequiredArgument]
        public InArgument<string> Range { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            string sourceFile = SourceFile.Get(context);
            string password = Password.Get(context);
            string range = Range.Get(context);
            PdfReader reader;

            if (string.IsNullOrEmpty(password))
                reader = new PdfReader(sourceFile);
            else
                reader = new PdfReader(sourceFile, Encoding.ASCII.GetBytes(password));

            Document outputDocument;
            PdfImportedPage importedPage;
            PdfCopy pdfCopyProvider;

            int startPage;
            int endpage;
            int counter = 1;

            foreach (string pageRange in range.Split(','))
            {
                outputDocument = new Document();

                if (pageRange.Contains("-"))
                {
                    if (int.TryParse(pageRange.Split('-')[0], out startPage) && int.TryParse(pageRange.Split('-')[1], out endpage))
                    {
                        if (startPage >= 1 && PDFHelpers.GetPageCount(sourceFile) >= endpage)
                        {
                            pdfCopyProvider = new PdfCopy(outputDocument, new FileStream(sourceFile.Replace(".pdf", "_" + pageRange + ".pdf"), FileMode.Create));

                            outputDocument.Open();
                            for (int i = startPage; i <= endpage; i++)
                            {
                                importedPage = pdfCopyProvider.GetImportedPage(reader, i);
                                pdfCopyProvider.AddPage(importedPage);
                            }
                        }
                    }
                    else throw new IOException("Invalid Range");
                }
                else if (int.TryParse(pageRange, out startPage))
                {
                    pdfCopyProvider = new PdfCopy(outputDocument, new FileStream(sourceFile.Replace(".pdf", counter + ".pdf"), FileMode.Create));

                    outputDocument.Open();
                    importedPage = pdfCopyProvider.GetImportedPage(reader, startPage);
                    pdfCopyProvider.AddPage(importedPage);
                }
                else throw new IOException("Invalid Range");

                counter++;
                outputDocument.Close();
            }

            reader.Close();
        }
    }
}