﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Activities;
using System.ComponentModel;
using System.IO;

namespace App_Integration.PDF.Extended
{
    [DisplayName("Merge PDF")]
    public class MergePDFs : CodeActivity
    {
        [DisplayName("Source Files")]
        [Category("Input")]
        [RequiredArgument]
        public InArgument<string[]> SourceFiles { get; set; }

        [DisplayName("Output File")]
        [Category("Output")]
        [RequiredArgument]
        public InArgument<string> OutputFile { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            string[] sourceFiles = SourceFiles.Get(context);
            string outputFile = OutputFile.Get(context);

            PdfReader reader = null;
            PdfImportedPage importedPage;
            Document sourceDocument = new Document();
            PdfCopy pdfCopyProvider = new PdfCopy(sourceDocument, new FileStream(outputFile, FileMode.Create));
            sourceDocument.Open();

            foreach (string filePath in sourceFiles)
            {
                int pages = PDFHelpers.GetPageCount(filePath);
                reader = new PdfReader(filePath);

                for (int i = 1; i <= pages; i++)
                {
                    importedPage = pdfCopyProvider.GetImportedPage(reader, i);
                    pdfCopyProvider.AddPage(importedPage);
                }

                reader.Close();
            }

            sourceDocument.Close();
        }
    }
}